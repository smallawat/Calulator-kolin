# Flutter Calculator

A simple calculator app using Flutter

![alt text](./Screenshot.png "Screenshot")
